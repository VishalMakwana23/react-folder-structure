const removeElementFromArray = (arr, value) => arr.filter((el) => el !== value);

export default removeElementFromArray;
